﻿namespace Ado_project
{
    partial class Insert1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbempid = new System.Windows.Forms.TextBox();
            this.tbempname = new System.Windows.Forms.TextBox();
            this.tbdob = new System.Windows.Forms.TextBox();
            this.tbphone = new System.Windows.Forms.TextBox();
            this.tbsalary = new System.Windows.Forms.TextBox();
            this.tbemail = new System.Windows.Forms.TextBox();
            this.tbdeptid = new System.Windows.Forms.TextBox();
            this.btninsert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 279);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(763, 159);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "EMPID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "EMPNAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(61, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "DOB";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(61, 124);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "PHONE";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(61, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "SALARY";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(61, 199);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "EMAIL";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(61, 236);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "DEPTID";
            // 
            // tbempid
            // 
            this.tbempid.Location = new System.Drawing.Point(167, 8);
            this.tbempid.Name = "tbempid";
            this.tbempid.Size = new System.Drawing.Size(100, 22);
            this.tbempid.TabIndex = 8;
            // 
            // tbempname
            // 
            this.tbempname.Location = new System.Drawing.Point(167, 46);
            this.tbempname.Name = "tbempname";
            this.tbempname.Size = new System.Drawing.Size(100, 22);
            this.tbempname.TabIndex = 9;
            // 
            // tbdob
            // 
            this.tbdob.Location = new System.Drawing.Point(167, 85);
            this.tbdob.Name = "tbdob";
            this.tbdob.Size = new System.Drawing.Size(100, 22);
            this.tbdob.TabIndex = 10;
            // 
            // tbphone
            // 
            this.tbphone.Location = new System.Drawing.Point(167, 119);
            this.tbphone.Name = "tbphone";
            this.tbphone.Size = new System.Drawing.Size(100, 22);
            this.tbphone.TabIndex = 11;
            // 
            // tbsalary
            // 
            this.tbsalary.Location = new System.Drawing.Point(167, 159);
            this.tbsalary.Name = "tbsalary";
            this.tbsalary.Size = new System.Drawing.Size(100, 22);
            this.tbsalary.TabIndex = 12;
            // 
            // tbemail
            // 
            this.tbemail.Location = new System.Drawing.Point(167, 194);
            this.tbemail.Name = "tbemail";
            this.tbemail.Size = new System.Drawing.Size(100, 22);
            this.tbemail.TabIndex = 13;
            // 
            // tbdeptid
            // 
            this.tbdeptid.Location = new System.Drawing.Point(167, 231);
            this.tbdeptid.Name = "tbdeptid";
            this.tbdeptid.Size = new System.Drawing.Size(100, 22);
            this.tbdeptid.TabIndex = 14;
            // 
            // btninsert
            // 
            this.btninsert.Location = new System.Drawing.Point(340, 218);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(137, 35);
            this.btninsert.TabIndex = 15;
            this.btninsert.Text = "INSERT DATA";
            this.btninsert.UseVisualStyleBackColor = true;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // Insert1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btninsert);
            this.Controls.Add(this.tbdeptid);
            this.Controls.Add(this.tbemail);
            this.Controls.Add(this.tbsalary);
            this.Controls.Add(this.tbphone);
            this.Controls.Add(this.tbdob);
            this.Controls.Add(this.tbempname);
            this.Controls.Add(this.tbempid);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Insert1";
            this.Text = "Form1";
           
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbempid;
        private System.Windows.Forms.TextBox tbempname;
        private System.Windows.Forms.TextBox tbdob;
        private System.Windows.Forms.TextBox tbphone;
        private System.Windows.Forms.TextBox tbsalary;
        private System.Windows.Forms.TextBox tbemail;
        private System.Windows.Forms.TextBox tbdeptid;
        private System.Windows.Forms.Button btninsert;
    }
}

