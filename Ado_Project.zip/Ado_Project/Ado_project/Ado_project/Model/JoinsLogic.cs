﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Ado_project.Model
{
    class JoinsLogic
    {
        private string conStr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

        public DataTable getCommanDetails()
        {
            DataTable table = new DataTable();
            SqlConnection conn = new SqlConnection(conStr);
            string sql = "SELECT E.EMPID,E.EMPNAME,E.SALARY,D.DEPTID,D.DEPTNAME,D.DLOCATION,D.MANAGERID FROM EMPLOYEE E INNER JOIN DEPARTMENT D ON E.DEPTID=D.DEPTID"; 
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(table);
                MessageBox.Show("Data retrived successfully!!");
            }
            catch(Exception)
            {
                MessageBox.Show("Failed to connect!!");
            }
            finally
            {
                conn.Close();

            }
            return table;
        }
    }
}
