﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ado_project.Model
{
    class Employee
    {
        public int empid { get; set; }
        public string empname { get; set; }
        public string dob { get; set; }
        public string phone { get; set; }
        public float salary { get; set; }
        public string email { get; set; }
        public int deptid { get; set; }
    }
}
