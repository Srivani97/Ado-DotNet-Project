﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ado_project.Model
{
    class Department
    {
        public int deptid { get; set; }
        public string deptname { get; set; }
        public string dlocation { get; set; }
        public int managerid { get; set; }
    }
}
