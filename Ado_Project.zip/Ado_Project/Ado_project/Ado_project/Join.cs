﻿using Ado_project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ado_project
{
    public partial class Join : Form
    {
        JoinsLogic ob;
        public Join()
        {           
            InitializeComponent();
            ob = new JoinsLogic();
        }

        private void Join_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getCommanDetails();

        }
    }
}
